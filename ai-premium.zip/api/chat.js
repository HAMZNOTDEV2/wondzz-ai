// Vercel Edge Function: proxy ke API OpenAI-compatible, mendukung streaming.
// API key diambil dari env var API_KEY (disarankan). Jika tidak diset,
// fallback ke key yang dikirim pengguna lewat header x-user-key.
export const config = { runtime: 'edge' };

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });

export default async function handler(req) {
  if (req.method !== 'POST') return json({ error: { message: 'Method not allowed' } }, 405);

  const host = (process.env.API_HOST || 'https://router.bangunweb.com/v1').replace(/\/+$/, '');
  const key = process.env.API_KEY || req.headers.get('x-user-key') || '';
  if (!key) {
    return json(
      { error: { code: 'no_key', message: 'API key belum diatur. Isi di Pengaturan atau set env API_KEY di Vercel.' } },
      401
    );
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: { message: 'Body JSON tidak valid' } }, 400);
  }
  body.model = body.model || process.env.API_MODEL || 'deepseek-v4.1-flash';

  try {
    const upstream = await fetch(`${host}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify(body),
    });
    return new Response(upstream.body, {
      status: upstream.status,
      headers: {
        'Content-Type': upstream.headers.get('content-type') || 'application/json',
        'Cache-Control': 'no-store',
        'X-Accel-Buffering': 'no',
      },
    });
  } catch (e) {
    return json({ error: { message: 'Gagal menghubungi upstream: ' + (e?.message || e) } }, 502);
  }
}
