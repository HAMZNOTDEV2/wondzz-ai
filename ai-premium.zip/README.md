# Lumen — Website AI Premium

Chat AI dengan streaming, riwayat percakapan, markdown + blok kode, dan 3 tema:

1. **Normal** — bersih, terang, fokus ke teks
2. **Liquid Glass** — kaca buram dengan latar warna yang bergerak pelan
3. **Terminal Amber** — gaya terminal fosfor amber, font monospace

## Isi proyek

```
index.html     Frontend (satu file, tanpa build)
api/chat.js    Proxy Vercel Edge (menyembunyikan API key, streaming)
vercel.json    Konfigurasi Vercel
.env.example   Contoh environment variable
```

## Deploy ke Vercel

1. Upload folder ini ke GitHub, lalu **Add New → Project** di Vercel dan pilih repo-nya.
   Atau dari terminal: `npm i -g vercel && vercel`.
2. Di **Settings → Environment Variables** tambahkan:

| Nama | Nilai |
|---|---|
| `API_KEY` | API key kamu |
| `API_HOST` | `https://router.bangunweb.com/v1` |
| `API_MODEL` | `deepseek-v4.1-flash` |

3. **Redeploy** setelah menambah variable. Selesai.

API key hanya ada di server, tidak pernah dikirim ke browser pengunjung.

## Tanpa env var?

Kalau `API_KEY` tidak diatur di Vercel, buka **Pengaturan** di website lalu isi API key.
Key itu disimpan di browser sendiri dan dikirim lewat header ke proxy. Cocok untuk pemakaian pribadi,
tapi untuk website publik sebaiknya pakai env var supaya key tidak bisa dipakai orang lain.

## Jalankan lokal

```
npm i -g vercel
cp .env.example .env   # isi API_KEY
vercel dev
```

Membuka `index.html` langsung dari file tidak akan jalan karena `/api/chat` butuh server.
